<!DOCTYPE html>
<html> 
<head>
<title>Location</title>
<link rel="shortcut icon" type="image/icon" href="  file:///C:/Users/user/Downloads/apple-400x400.png ">
</head>
<body style="background-color:white;">
<h1 style="color:white; text-align: center;font-size: 50px; background-color:seagreen; border-radius:5px;">About Us</h1>
<br>
<p id="para_1" class="Web devolopment" style="text-align:justify ; ">
    
  We believe that buying a car specially here in Bangladesh is no joke. We want you to invest your hard earned money in to the right car, for that we’ll guide you to choose the right one for you. After that when you start driving you must know some basic maintenance and safety stuffs. You should which repair cost how much, where you can get the authentic and right parts. We will guide you.Even in this saturated market where you buy a parts or accessories thinking it’s legit, there is high chances of being 5th grade copy product you bought. Carhub will guide you what and where to buy. So that end of the day you can sleep well; your car got the right parts it needs.
  Not only that we teach how to identify fake thing and how to verify the right one. Stay Connected!
  </p>  

  <p id="para_1" class="Web devolopment" style="text-align:justify ; ">

    Founded in 2018, Carhub is a highly trusted and largest automotive platform in Bangladesh. We have nearly about 1M active followers across our social platforms, which lead us to the largest automotive platform in the country. We decided to creat a platform like this when we noticed in our country car owners have very little knowledge on how to maintain their cars, how to fix it, how much should it cost etc. Whenever you try to search on these things literally you’ll find no information relevant to our market. Even knowing simple a car price requires you to call 2-3 sellers! Then we founded Carhub, initially a Facebook page and group (which by the way now the largest car community in Bangladesh). We started providing valuable content on how you maintain your cars, what you should do or don’t. Which car should you buy, how much should pay for a specific repair, what’s the condition of current market etc. Not only that if you face any troubleshoot with your car you can ask Carhub, our experts suggests them for free. 

  </p>  
  
  <h3 style="color:white; text-align: center;font-size: 30px; background-color:seagreen; padding:10px; border-radius:5px; ">Map Location</h3>
  
  <h3 style="color: seagreen; text-align:left;">Click Below To Get Live Direction</h3>
  
<a href="https://www.google.com/maps/place/Rancon+Car+Hub+Ltd./@23.7918481,90.4213778,15z/data=!4m14!1m7!3m6!1s0x3755c7a3f541df2f:0xbe7c997e5136a523!2sRancon+Car+Hub+Ltd.!8m2!3d23.7925349!4d90.4187627!16s%2Fg%2F11cr_zgcl1!3m5!1s0x3755c7a3f541df2f:0xbe7c997e5136a523!8m2!3d23.7925349!4d90.4187627!16s%2Fg%2F11cr_zgcl1?entry=ttu"> <img src="map.png" height="100%" width="100%" style="border: 2px solid seagreen;"> </a>


<h3 style="color:seagreen;">Mission</h3>

  <p id="para_1" class="Web devolopment" style="text-align:justify ; ">
    Our Mission is to continue providing up-to-date valuable car content, making in depth videos and doing podcasts with our industry experts. Also we’re working on developing a complete authentic and trusted car parts and accessories chain to provide 100% Authentic products. As we’re getting so much requests daily from our audience that everytime they buy something or service their cars, they got scammed. They want a super reliable name like carhub to come up with a solution. 
  </p>  


  <h3 style="color: seagreen;">Our Expertise</h3>

  <p id="para_1" class="Web devolopment" style="text-align:justify ; ">
    We got popularity at a very short time just because of our expertise in the field. The information or suggestions we provide is highly accurate and comes from our team members years of experience. We have expert on legal and import, repairing and cost, regular maintenance, engine and technical issues etc. Also some of our team member are in Japan. They can talk to Toyota, Hondas directly if needed. In a word this is the place where you will get proper help and guideline in Bangla. 
  </p>  




  


</body>
</html>